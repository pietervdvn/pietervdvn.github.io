#!/bin/bash

if [ $# -eq 0 ]
	then
		echo ""
		echo "  No arguments supplied."
		echo "  You need to supply at least 1 argument being the folder of the language, e.g. en, fr or nl."
		echo "  With only 1 argument given the script will generate defaults for the other arguments."
		echo "  It is best to supply all 3 arguments."
		echo ""
		echo "  $ gen_manual_voice.sh <language folder> <language> <prefix for zip file>"
		echo ""
		echo "  examples:"
		echo "    ./gen_manual_voice.sh de German de"
		echo ""
		echo " The script requires a package for the prolog language to be installed, e.g. swi-prolog."
		echo " Be sure that your console/terminal locale matches the character encoding"
		echo " of the source ttsconfig.p file of the language, e.g. UTF8."
		echo ""
		exit 1
fi

BOLD="$(tput bold)"
NORMAL="$(tput sgr0)"

CONFIG_FILE="$1/config.p"
TARGET_FILE="$3"
if [ -z $TARGET_FILE ]; then TARGET_FILE="$2"; fi
NORMALISE="$4"
if [ -z "$NORMALISE" ]; then NORMALISE=yes; fi

echo "${BOLD}Generating voice metadata for $2${NORMAL}"

mkdir -p work
echo "%%% !!! THIS IS A GENERATED FILE !!! Modify ttsconfig.p" > "$CONFIG_FILE"

[ ! -r "$1/ttsconfig.p" ] && echo "ttsconfig.p file is missing in language folder!" && exit 1
sed "s/version(10[2-3])/version(0)/g" "$1/ttsconfig.p" >> "$CONFIG_FILE"

cp "$CONFIG_FILE" work/_config.p
cd work
# clear previous files
# rm -f *.wav *.mp3 $1.zip

[ ! -r ../gen_config.p ] && echo "gen_config.p file is missing!" && exit 1

rm -rf ./*.ogg
cp -t . "../$1/voice/"*.ogg

### for t in `ls *.wav` ; do oggenc $t ; done
# function updateFile { Og=${1::-4} && sox $1 r${Og}.ogg reverse && sox r${Og}.ogg ${Og}.ogg silence 1 0.1 0.01% reverse && rm r${Og}.ogg; }
# for t in `ls *.ogg` ; do Og=${t::-4} && sox $t r${Og}.ogg reverse && sox r${Og}.ogg ${Og}.ogg silence 1 0.1 0.01% reverse && rm r${Og}.ogg; done
#echo "Reducing the silence..."
# see http://sox.sourceforge.net/sox.html silence
#for t in `ls *.wav *.ogg`; do
#	Og=${t%????}
#	sox $t TEMPreverse_${Og}.ogg reverse
#	sox TEMPreverse_${Og}.ogg ${Og}.ogg silence 1 0.1 0.01% reverse
#	rm TEMPreverse_${Og}.ogg
#done

# normalise
if [ $NORMALISE == "yes" ]; then
	echo "Normalising audio..."
	for Og in $(ls *.ogg); do
		cp "${Og}" "TEMPslow_${Og}"
		sox "TEMPslow_${Og}" "${Og}" gain -n
		rm "TEMPslow_${Og}"
	done
fi

echo "Packaging voice files..."
echo "Voice Data $2 ($TARGET_FILE)" | zip ${TARGET_FILE}_0.voice.zip _config.p -c
touch .nomedia
zip "${TARGET_FILE}_0.voice.zip" *.ogg .nomedia

rm -rf *.ogg

echo ""
echo "### You can find your zipped voice file ${TARGET_FILE}_0.voice.zip in the folder work ###"
echo ""

# vim: set noet ts=2 sw=2:
