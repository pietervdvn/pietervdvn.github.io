#!/bin/bash

grep -E "^string\('" ttsconfig.p | sed -r "s/.*'(.*)', '(.*)'.*/\1,\"\2\"/g"  > parts.csv
for i in $(seq 1 20; seq 25 5 100; seq 150 50 1000; seq 2000 1000 9000); do
  echo "$i.ogg,$i" >> parts.csv
done

rm prts.csv
touch prts.csv
while read part
do
    NAME=`echo $part | sed "s/,.*//"`
    if [ ! -f $1$NAME ]
    then
        echo "Missing: $NAME"
        echo "$part,MISSING" >>prts.csv
    else
        echo "$part,OK" >>prts.csv
    fi
done <parts.csv
